package BinaryTree;

public class BinaryTree {
    private Node root;

    public BinaryTree(int rootValue) {
        root = new Node(rootValue,null,null);
    }

    private void insert(Node newNode, Node root){
        if(newNode.getValue()< root.getValue()){
            if(root.getLeft()==null){
                root.setLeft(newNode);
            }
            else {
                insert(newNode,root.getLeft());
            }
        }
        if(newNode.getValue()> root.getValue()){
            if(root.getRight()==null){
                root.setRight(newNode);
            }
            else {
                insert(newNode,root.getRight());
            }
        }
        else {
            System.out.println("Duplicated values not allowed");
        }

    }

    public void insertNode(int value){
        Node newNode=new Node(value,null,null);
        insert(newNode,root);
    }

    private boolean search(int value,Node node){
        if(node==null) return false;

        if(value> node.getValue())
            return search(value,node.getRight());
        else if  (value< node.getValue())
            return search(value,node.getLeft());
        else return true;
    }

    public boolean searchNode(int svalue){
        return search(svalue,root);
    }

    private void preOrderTraversal(Node node){
        if (node==null) return;
        System.out.print(node.getValue()+" ");
        preOrderTraversal(node.getLeft());
        preOrderTraversal(node.getRight());
    }

    public void preOrder(){
        preOrderTraversal(root);
        System.out.println();
    }

    private void inOrderTraversal(Node node){
        if (node==null) return;
        inOrderTraversal(node.getLeft());
        System.out.print(node.getValue()+" ");
        inOrderTraversal(node.getRight());
    }

    public void inOrder(){
        inOrderTraversal(root);
        System.out.println();
    }

    private void postOrderTraversal(Node node){
        if (node==null) return;
        postOrderTraversal(node.getLeft());
        postOrderTraversal(node.getRight());
        System.out.print(node.getValue()+" ");
    }

    public void postOrder(){
        postOrderTraversal(root);
        System.out.println();
    }




    class Node{
    private int value;
    private Node left;
    private Node right;

    public Node(int value, Node left, Node right) {
        this.value = value;
        this.left = left;
        this.right = right;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }
}
}
