package graph;

import SingleLinkedList.SingleLinkedList;

public class AdjacencyList {
    private SingleLinkedList<Integer> []adjlist;
    private int vertices;
    private int edges;

    public AdjacencyList(int nodes) {
        adjlist= new SingleLinkedList[nodes];
        vertices=nodes;
        edges=0;
        for (int i = 0; i < nodes; i++) {
            adjlist[i] = new SingleLinkedList<Integer>();
        }
    }

    public void addEdge(int from, int to){
        if (from < 0 || from >= vertices || to < 0 || to >= vertices) {
            throw new IllegalArgumentException("Invalid vertices");
        }
        
        if (adjlist[from] == null) {
            adjlist[from] = new SingleLinkedList<Integer>();
        }
        adjlist[from].addLast(to);
        adjlist[to].addLast(from);
        edges++;
    }

//    public void removeEdge(int from, int to){
//        if (from < 0 || from >= vertices || to < 0 || to >= vertices) {
//            throw new IllegalArgumentException("Invalid vertices");
//        }
//        if (adjlist[from] == null) {
//            return;
//        }
//        adjlist[from].remove(to);
//        edges--;
//    }

    public void display(){
        System.out.println(vertices + "V"+ edges + "E");
        for (int v=0; v<vertices; v++){
            System.out.println(v+": ");
            adjlist[v].display2();
        }
    }
}
