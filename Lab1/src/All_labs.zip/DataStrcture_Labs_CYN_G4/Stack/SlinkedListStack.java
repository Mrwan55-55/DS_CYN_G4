package Stack;

public class SlinkedListStack <E> implements Stack<E> {

    SingleLinkedList <E> slist=new SingleLinkedList<E>();


    @Override
    public boolean isEmpty() {
        return slist.isEmpty();
    }

    @Override
    public int size() {
        return slist.Size();
    }

    @Override
    public void push(E data) {
        slist.addFirst(data);
    }

    @Override
    public E top() {
        return slist.getFirst();
    }

    @Override
    public E pop() {
        return slist.removeFirst();
    }

    @Override
    public void display() {

    }
}
