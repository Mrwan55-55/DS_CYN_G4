package Stack;

public interface Stack<E> {
    boolean isEmpty ();
    public int size();
    public void push(E data);
    public E top();
    public E pop();
    public void display();

}
