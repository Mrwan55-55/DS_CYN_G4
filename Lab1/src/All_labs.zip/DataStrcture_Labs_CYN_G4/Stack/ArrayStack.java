package Stack;

public class ArrayStack<E> implements Stack<E>{
    private E arr[];
    private int t=-1;
    private static final int CAPACITY=1000;

//    public ArrayStack() {
//        arr=(E[]) new Object[CAPACITY];
//        /// /////////////////////////////////important/////////////////////////
//
//    }

        public ArrayStack(int c) {
        arr=(E[]) new Object[c];
        /// /////////////////////////////////important/////////////////////////

    }

    public ArrayStack() {
            this(CAPACITY);
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public void push(E data) {
    if (size()==arr.length){
        throw new IllegalStateException("stack is full");
    }
    else {
        arr[++t]=data;
    }
    }

    @Override
    public E top() {
            if(isEmpty()) return null;
            return arr[t];
    }

    @Override
    public E pop() {
        if (isEmpty()) return null;
        E delete=arr[t];
        arr[t]=null;
        t--;
        return delete;
    }

    @Override
    public void display() {

    }
}
