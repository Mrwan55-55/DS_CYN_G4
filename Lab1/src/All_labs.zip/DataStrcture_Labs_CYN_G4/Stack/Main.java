package Stack;

public class Main {
    public static void main(String[] args) {
        SlinkedListStack<Integer> slStack=new SlinkedListStack<Integer>();
        slStack.push(3);
        slStack.push(4);
        slStack.push(5);
        slStack.pop();
        slStack.size();
        slStack.top();
        slStack.isEmpty();

    }
}
