package Queue;

public class Main {

    public static void main(String[] args) {
        ArrayQueue<Integer> lqueue=new ArrayQueue<Integer>(3);
        lqueue.enqueue(10);
        lqueue.enqueue(20);
        lqueue.enqueue(30);

        System.out.println("the front is:"+lqueue.front());
        lqueue.dequeue();//1
        lqueue.dequeue();//2
        lqueue.dequeue();//3


        lqueue.enqueue(40);
        System.out.println(lqueue.front());

        System.out.println(lqueue.dequeue());




//        while (!lqueue.isEmpty()){
//            System.out.println("element removed :"+lqueue.dequeue());
//
//        }

    }
}
