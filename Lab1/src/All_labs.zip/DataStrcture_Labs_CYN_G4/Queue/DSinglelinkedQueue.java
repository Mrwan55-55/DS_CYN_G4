package Queue;

import DSingleLinkedList.DSingleLinkedList;
public class DSinglelinkedQueue<E> implements Queue<E> {
    DSingleLinkedList<E> slist=new DSingleLinkedList<E>();
        @Override
        public E dequeue() {
            return slist.removeFirst();
        }

        @Override
        public boolean isEmpty() {
            return slist.isEmpty();
        }

        @Override
        public int size() {
            return slist.size();
        }

        @Override
        public void enqueue(E data) {
            slist.addLast(data);
        }

        @Override
        public E front() {
            return slist.getFirst();
        }


        public E rear() {
            return slist.getLast();
        }
    }

