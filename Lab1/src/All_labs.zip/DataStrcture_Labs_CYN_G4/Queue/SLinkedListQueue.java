package Queue;
import SingleLinkedList.SingleLinkedList;
public class SLinkedListQueue<E> implements Queue<E> {
    SingleLinkedList<E> slist=new SingleLinkedList<E>();
    @Override
    public E dequeue() {
        return slist.removeFirst();
    }

    @Override
    public boolean isEmpty() {
        return slist.isEmpty();
    }

    @Override
    public int size() {
        return slist.size();
    }

    @Override
    public void enqueue(E data) {
    slist.addLast(data);
    }

    @Override
    public E front() {
        return slist.getFirst();
    }

//    @Override
//    public E rear() {
//        return slist.getLast();
//    }
    public void display()
    {
        slist.display2();
    }

}
